import { useDispatch } from "react-redux";
import { removefromCart } from "../utils/cartSlice";
export default function CartItem({product}){
    const dispatch= useDispatch();
    return(
        <>
        <h2>{product.title}</h2>
        <img src={product.images[0]} width="200px" height="200px"/>
        <h2>Category:{product.category}</h2>
        <h2>Price:{product.price}</h2>
        <button onClick={()=>dispatch(removefromCart(product))}>Remove from Cart</button>
        </>
    )
}