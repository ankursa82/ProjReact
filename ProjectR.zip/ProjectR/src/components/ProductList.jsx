import useFetchProds from "../utils/useFetchProds";
import ProdItem from "./ProdItem";
import Error from "./Error";
import { useState } from "react";
import '../App.css';
export default function Prodlist(){
    const {prods, error, loading}= useFetchProds();
    const [value,setValue]=useState(null);
    const prody = prods.filter((prod)=>prod.title.includes(value));
   
    if(loading){
        return <h1>Loading...</h1>;
    }
    if(error){
        return <Error error={error}/>;
    }
    return(
        <>
        <div className="cont">
        <label for="search">Search Products:</label>
        <input type="text" id="search" onChange={(e)=>setValue(e.target.value)}/><br/>
          {!value?prods.map((prod)=>{
           return <ProdItem product={prod}/>;
        }):prody.map((prod)=>{
            return <ProdItem product={prod}/>;
         })}
         </div>
        </>    
    );
}
