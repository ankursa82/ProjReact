import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
function ProdDetail(){
    const { id }= useParams();
    const [product, setProduct]= useState(null);
    const [error, setError]= useState(null);
    useEffect(()=>{
        fetch(`https://dummyjson.com/products/${id}`)
        .then(resp=>resp.json())
        .then(data=>setProduct(data))
        .catch(err=>setError(err.message))
    },[id]);
    if (error) return <div>Error: {error}</div>;
    if (!product) return <div>Loading...</div>;
  
    return (
      <div>
        <h2>{product.title}</h2>
        <img src={product.images[0]} width="200px" height="200px"/>
        <h2>Category:{product.category}</h2>
        <h2>Price:{product.price}</h2>
        <h2>Rating:{product.rating}</h2>
        <p>{product.description}</p>
      </div>
    );
}
export default ProdDetail;