import axios from "axios";
import { useState,useEffect } from "react";
function useFetchProds(){
    const [prods, setProds]=useState([]);
    const [error,setError]= useState(null);
    const [loading,setLoading]=useState(true);
    useEffect(()=>{
      axios.get('https://dummyjson.com/products')
      .then((data)=>setProds(data.data.products))
      .catch(err=>setError(err.message))
      .finally(setLoading(false))
    },[]);
    return {prods, loading, error};
}
export default useFetchProds;