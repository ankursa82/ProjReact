
Project Repository path: https://github.com/ankursa82/ProjReact

Open the zip folder ProjectR.zip in main branch.

Save it in your laptop. Install node modules. Run the project.

Readme.md file path: https://github.com/ankursa82/ProjReact/blob/main/README.md